﻿Imports Snap, Snap.Create

Public Class MyProgram

    Public Shared Sub Main()

        ' Your code goes here

    End Sub

End Class
