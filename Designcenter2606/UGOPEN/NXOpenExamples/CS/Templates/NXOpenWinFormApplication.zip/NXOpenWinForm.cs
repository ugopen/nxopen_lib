﻿partial class NXOpenWinForm : System.Windows.Forms.Form
{}

