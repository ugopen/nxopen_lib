﻿using System.Windows.Forms;

public class MyProgram
{
    public static void Main()
    {
        // Declare and instantiate the form object
        NXOpenWinForm form = new NXOpenWinForm();

        // Show the form as a dialog
        form.ShowDialog();
    }
}
