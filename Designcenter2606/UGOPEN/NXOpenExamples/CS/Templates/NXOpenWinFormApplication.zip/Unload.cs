﻿using NXOpen;

public class Unload
{
    public static int GetUnloadOption(string dummy)
    {
        int unloadOption;

        unloadOption = (int)NXOpen.Session.LibraryUnloadOption.Immediately;        // After executing
        //unloadOption = (int)NXOpen.Session.LibraryUnloadOption.AtTermination;     // When NX session terminates
        //unloadOption = (int)NXOpen.Session.LibraryUnloadOption.Explicitly;        // Using File-->Unload

        return unloadOption;
    }
}