﻿using NXOpen;
public class Unload
{
    public static int GetUnloadOption(string dummy)
    {
        int unloadOption;

        unloadOption = (int)Session.LibraryUnloadOption.Immediately;       //After executing
        //unloadOption = (int)Session.LibraryUnloadOption.AtTermination;     //When NX session terminates
        //unloadOption = (int)Session.LibraryUnloadOption.Explicitly;        //Using File-->Unload

        return unloadOption;
    }
}

