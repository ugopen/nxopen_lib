﻿Public Class MyProgram

  Public Shared Sub Main()

    Dim form As New NXOpenWinForm()
    form.ShowDialog()

  End Sub

End Class
